1740476984 /home/student/Vatsal_58_VLSI/LAB7_1March/Question2/q_tb.v
1740476754 /home/student/Vatsal_58_VLSI/LAB7_1March/Question2/q.v
