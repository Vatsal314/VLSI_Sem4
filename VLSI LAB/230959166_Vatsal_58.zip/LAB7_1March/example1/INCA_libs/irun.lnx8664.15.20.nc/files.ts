1740818590 /home/student/Vatsal_58_VLSI/LAB7_1March/example1/cds.lib
1740818592 /home/student/Vatsal_58_VLSI/LAB7_1March/example1/hdl.var
1740473056 /home/student/Vatsal_58_VLSI/LAB7_1March/example1/fa.v
1740473346 /home/student/Vatsal_58_VLSI/LAB7_1March/example1/fa_tb.v
