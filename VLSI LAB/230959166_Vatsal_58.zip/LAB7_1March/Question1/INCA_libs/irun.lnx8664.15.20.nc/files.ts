1740819824 /home/student/Vatsal_58_VLSI/LAB7_1March/Question1/cds.lib
1740819826 /home/student/Vatsal_58_VLSI/LAB7_1March/Question1/hdl.var
1740476754 /home/student/Vatsal_58_VLSI/LAB7_1March/Question1/q.v
1740476984 /home/student/Vatsal_58_VLSI/LAB7_1March/Question1/q_tb.v
